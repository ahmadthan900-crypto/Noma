$ErrorActionPreference = "Stop"
$Frpc = Join-Path $PSScriptRoot "..\bin\frpc.exe"
$Config = Join-Path $PSScriptRoot "frpc.toml"

if (!(Test-Path $Frpc)) {
    Write-Host "Missing frpc.exe. Download the official FRP release and place frpc.exe in tunnel\bin\" -ForegroundColor Red
    exit 1
}
if (!(Test-Path $Config)) {
    Write-Host "Missing frpc.toml" -ForegroundColor Red
    exit 1
}
& $Frpc -c $Config
