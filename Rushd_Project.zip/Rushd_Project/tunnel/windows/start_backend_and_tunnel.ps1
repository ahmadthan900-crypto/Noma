$ErrorActionPreference = "Stop"
$Backend = Resolve-Path (Join-Path $PSScriptRoot "..\..\backend")
Set-Location $Backend

if (!(Test-Path ".venv\Scripts\python.exe")) {
    Write-Host "Create backend venv and install requirements first." -ForegroundColor Yellow
    exit 1
}
if (!(Test-Path ".env")) {
    Write-Host "Copy .env.example to .env and set strong secrets first." -ForegroundColor Yellow
    exit 1
}

$server = Start-Process -FilePath ".venv\Scripts\python.exe" `
    -ArgumentList "-m uvicorn app.main:app --host 127.0.0.1 --port 8000" `
    -PassThru -NoNewWindow

Start-Sleep -Seconds 3
try {
    $health = Invoke-RestMethod "http://127.0.0.1:8000/api/health" -TimeoutSec 5
    if (!$health.ok) { throw "Health check failed" }
    Write-Host "Rushd API is running." -ForegroundColor Green
} catch {
    Write-Host "API health check failed: $_" -ForegroundColor Red
    Stop-Process -Id $server.Id -Force -ErrorAction SilentlyContinue
    exit 1
}

Write-Host "Starting FRP client. Keep this window open."
& (Join-Path $PSScriptRoot "start_tunnel.ps1")
