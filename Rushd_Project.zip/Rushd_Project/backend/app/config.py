from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    app_env: str = "development"
    database_url: str = "sqlite:///./rushd.db"
    jwt_secret: str
    otp_pepper: str
    access_token_minutes: int = 15
    refresh_token_days: int = 30
    cors_origins: str = ""

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

settings = Settings()

def cors_origin_list() -> list[str]:
    return [x.strip() for x in settings.cors_origins.split(",") if x.strip()]
