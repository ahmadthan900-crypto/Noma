from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from .database import Base, engine
from . import models
from .auth import router as auth_router
from .config import cors_origin_list

app = FastAPI(title="Rushd API", version="0.1.0")

origins = cors_origin_list()
if origins:
    app.add_middleware(
        CORSMiddleware,
        allow_origins=origins,
        allow_credentials=False,
        allow_methods=["GET", "POST", "PUT", "DELETE"],
        allow_headers=["Authorization", "Content-Type"],
    )

@app.on_event("startup")
def startup():
    Base.metadata.create_all(bind=engine)

app.include_router(auth_router)

@app.get("/api/health")
def health():
    return {"ok": True, "service": "Rushd API", "version": app.version}
