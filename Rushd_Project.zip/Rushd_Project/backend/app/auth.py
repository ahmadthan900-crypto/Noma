import hashlib, hmac, secrets
from datetime import datetime, timedelta, timezone

import jwt
from argon2 import PasswordHasher
from argon2.exceptions import VerifyMismatchError, VerificationError
from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy import select
from sqlalchemy.orm import Session

from .config import settings
from .database import get_db
from .models import User, OTPChallenge, RefreshToken
from .schemas import RegisterIn, VerifyOTPIn, LoginIn, RefreshIn

router = APIRouter(prefix="/api/auth", tags=["Authentication"])
password_hasher = PasswordHasher()
oauth_scheme = OAuth2PasswordBearer(tokenUrl="/api/auth/login")

def now():
    return datetime.now(timezone.utc)

def hash_otp(code: str) -> str:
    return hmac.new(settings.otp_pepper.encode(), code.encode(), hashlib.sha256).hexdigest()

def hash_refresh(token: str) -> str:
    return hashlib.sha256(token.encode()).hexdigest()

def create_access(user_id: int) -> str:
    t = now()
    payload = {"sub": str(user_id), "type": "access", "iat": t, "exp": t + timedelta(minutes=settings.access_token_minutes)}
    return jwt.encode(payload, settings.jwt_secret, algorithm="HS256")

def issue_tokens(db: Session, user: User) -> dict:
    refresh = secrets.token_urlsafe(48)
    db.add(RefreshToken(user_id=user.id, token_hash=hash_refresh(refresh),
                        expires_at=now() + timedelta(days=settings.refresh_token_days)))
    db.flush()
    return {"access_token": create_access(user.id), "refresh_token": refresh,
            "token_type": "bearer", "expires_in": settings.access_token_minutes * 60}

def send_whatsapp_otp(phone: str, code: str):
    # Integrate an approved WhatsApp Business Platform provider here.
    # Deliberately fail closed: never pretend an OTP was sent.
    raise HTTPException(status_code=503, detail="WhatsApp provider is not configured")

@router.post("/register", status_code=202)
def register(data: RegisterIn, db: Session = Depends(get_db)):
    if db.scalar(select(User).where(User.phone == data.phone)):
        raise HTTPException(409, "Phone number already registered")
    user = User(name=data.name.strip(), phone=data.phone, age=data.age,
                password_hash=password_hasher.hash(data.password), is_verified=False)
    db.add(user)
    db.flush()
    code = f"{secrets.randbelow(1_000_000):06d}"
    challenge = OTPChallenge(phone=data.phone, code_hash=hash_otp(code),
                             expires_at=now() + timedelta(minutes=5))
    db.add(challenge)
    try:
        send_whatsapp_otp(data.phone, code)
    except Exception:
        db.rollback()
        raise
    db.commit()
    return {"message": "Verification request accepted"}

@router.post("/verify-otp")
def verify_otp(data: VerifyOTPIn, db: Session = Depends(get_db)):
    challenge = db.scalar(select(OTPChallenge).where(
        OTPChallenge.phone == data.phone, OTPChallenge.consumed.is_(False)
    ).order_by(OTPChallenge.id.desc()))
    if not challenge or challenge.expires_at <= now():
        raise HTTPException(400, "No valid verification request")
    if challenge.attempts >= 5:
        raise HTTPException(429, "Too many attempts")
    challenge.attempts += 1
    if not hmac.compare_digest(challenge.code_hash, hash_otp(data.code)):
        db.commit()
        raise HTTPException(400, "Incorrect verification code")
    user = db.scalar(select(User).where(User.phone == data.phone))
    if not user:
        raise HTTPException(404, "Account not found")
    user.is_verified = True
    challenge.consumed = True
    db.commit()
    return {"message": "Account verified"}

@router.post("/login")
def login(data: LoginIn, db: Session = Depends(get_db)):
    user = db.scalar(select(User).where(User.phone == data.phone))
    valid = False
    if user:
        try:
            valid = password_hasher.verify(user.password_hash, data.password)
        except (VerifyMismatchError, VerificationError):
            valid = False
    if not valid:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Incorrect phone or password")
    if not user.is_verified or user.is_banned:
        raise HTTPException(403, "Account is not available")
    result = issue_tokens(db, user)
    db.commit()
    return result

@router.post("/refresh")
def refresh(data: RefreshIn, db: Session = Depends(get_db)):
    record = db.scalar(select(RefreshToken).where(
        RefreshToken.token_hash == hash_refresh(data.refresh_token)
    ))
    if not record or record.revoked or record.expires_at <= now():
        raise HTTPException(401, "Invalid refresh token")
    user = db.get(User, record.user_id)
    if not user or not user.is_verified or user.is_banned:
        raise HTTPException(401, "Account unavailable")
    record.revoked = True
    result = issue_tokens(db, user)
    db.commit()
    return result

@router.post("/logout")
def logout(data: RefreshIn, db: Session = Depends(get_db)):
    record = db.scalar(select(RefreshToken).where(
        RefreshToken.token_hash == hash_refresh(data.refresh_token)
    ))
    if record:
        record.revoked = True
        db.commit()
    return {"message": "Logged out"}

@router.get("/me")
def me(token: str = Depends(oauth_scheme), db: Session = Depends(get_db)):
    try:
        payload = jwt.decode(token, settings.jwt_secret, algorithms=["HS256"])
        if payload.get("type") != "access":
            raise ValueError("wrong token type")
        user_id = int(payload["sub"])
    except (jwt.InvalidTokenError, KeyError, ValueError):
        raise HTTPException(401, "Invalid or expired token")
    user = db.get(User, user_id)
    if not user or not user.is_verified or user.is_banned:
        raise HTTPException(401, "Account unavailable")
    return {"id": user.id, "name": user.name, "phone": user.phone, "role": user.role}
