from pydantic import BaseModel, Field, ConfigDict

class RegisterIn(BaseModel):
    name: str = Field(min_length=2, max_length=100)
    phone: str = Field(pattern=r"^09\d{8}$")
    age: int = Field(ge=13, le=120)
    password: str = Field(min_length=12, max_length=128)

class VerifyOTPIn(BaseModel):
    phone: str = Field(pattern=r"^09\d{8}$")
    code: str = Field(pattern=r"^\d{6}$")

class LoginIn(BaseModel):
    phone: str = Field(pattern=r"^09\d{8}$")
    password: str

class RefreshIn(BaseModel):
    refresh_token: str

class TokenOut(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    expires_in: int

class UserOut(BaseModel):
    id: int
    name: str
    phone: str
    role: str
    model_config = ConfigDict(from_attributes=True)
