# مشروع رُشد (Rushd) — حزمة تأسيسية

هذه الحزمة نقطة انطلاق قابلة للتطوير، وليست نسخة إنتاجية مكتملة أو مختبرة على جهازك.

## المحتويات
- `backend/`: FastAPI + SQLAlchemy + SQLite + Argon2id + JWT.
- `tunnel/`: إعدادات FRP للطرف المحلي على Windows والطرف العام على VPS.
- `mobile/rushd_flutter/`: تطبيق Flutter أولي بواجهة RTL وأربعة تبويبات.

## متطلبات التشغيل
- Windows 10 مع Python 3.11 أو أحدث.
- Flutter SDK وAndroid SDK لبناء APK.
- لخدمة FRP: خادم VPS عام مع عنوان IP ثابت أو اسم نطاق، وإمكانية فتح منفذ TCP مخصص.

## تشغيل السيرفر على Windows
1. افتح PowerShell داخل مجلد `backend`.
2. نفّذ:
   ```powershell
   py -3 -m venv .venv
   .\.venv\Scripts\Activate.ps1
   pip install -r requirements.txt
   Copy-Item .env.example .env
   ```
3. أنشئ مفاتيح سرية قوية وضعها في `.env`:
   ```powershell
   python -c "import secrets; print(secrets.token_urlsafe(48))"
   ```
   شغّل الأمر مرتين واستخدم الناتجين لـ `JWT_SECRET` و`OTP_PEPPER`.
4. شغّل:
   ```powershell
   uvicorn app.main:app --host 127.0.0.1 --port 8000
   ```
5. افحص `http://127.0.0.1:8000/api/health`.

## إعداد النفق
FRP ليس شبكة وسيطة مجانية جاهزة؛ يجب تثبيت `frps` على VPS و`frpc` على كمبيوتر Windows.
- عدّل `tunnel/vps/frps.toml` على VPS.
- عدّل `tunnel/windows/frpc.toml` وضع عنوان VPS ورمزاً سرياً قوياً مطابقاً.
- انسخ ملفات FRP الرسمية من صفحة الإصدارات إلى مجلد `tunnel/bin/`:
  https://github.com/fatedier/frp/releases
- شغّل `frps` على VPS أولاً، ثم `tunnel/windows/start_tunnel.ps1`.
- لا تفتح منفذ لوحة تحكم FRP للإنترنت. استخدم جدار حماية VPS وTLS/HTTPS أمام واجهة API في إعداد إنتاجي.

**مهم:** المثال يستخدم منفذ FRP خاصاً للوصول إلى خدمة API. يلزم إعداد HTTPS موثوق على VPS (مثلاً Caddy أو Nginx مع شهادة TLS) قبل استخدامه من هواتف خارج شبكتك. لا تستخدم HTTP غير مشفر لتسجيل الدخول.

## تشغيل Flutter
```powershell
cd mobile/rushd_flutter
flutter pub get
flutter run
```
لبناء APK:
```powershell
flutter build apk --release
```

## حدود هذه النسخة
- WhatsApp OTP: نقطة تكامل فقط؛ لا ترسل رسائل حتى تضف مزود WhatsApp Business Platform رسمياً.
- رفع الملفات ومراجعة المحتوى وقيود Reels والمراسلة والمجموعات والكاش المحلي ليست مكتملة بعد.
- SQLite مناسب للتطوير والتجارب المحدودة. للإطلاق العام استخدم PostgreSQL وتخزين ملفات مناسباً ونسخاً احتياطية ومراقبة.
- لا تضع أسرار JWT أو مفاتيح النفق داخل تطبيق Flutter.
