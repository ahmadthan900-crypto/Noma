import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

void main() => runApp(const RushdApp());

class RushdApp extends StatelessWidget {
  const RushdApp({super.key});

  @override
  Widget build(BuildContext context) {
    const green = Color(0xFF4ADE80);
    const background = Color(0xFF0D1117);
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'رُشد',
      locale: const Locale('ar'),
      supportedLocales: const [Locale('ar'), Locale('en')],
      localizationsDelegates: GlobalMaterialLocalizations.delegates,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: background,
        colorScheme: ColorScheme.fromSeed(
          seedColor: green,
          brightness: Brightness.dark,
          surface: const Color(0xFF161B22),
        ),
        useMaterial3: true,
      ),
      home: const Directionality(
        textDirection: TextDirection.rtl,
        child: RushdShell(),
      ),
    );
  }
}

class RushdShell extends StatefulWidget {
  const RushdShell({super.key});
  @override
  State<RushdShell> createState() => _RushdShellState();
}

class _RushdShellState extends State<RushdShell> {
  int index = 0;
  final pages = const [
    _PlaceholderPage(title: 'الرئيسية', subtitle: 'أهلاً بك في رُشد'),
    _PlaceholderPage(title: 'مقاطع تعليمية', subtitle: 'المحتوى التعليمي سيظهر هنا'),
    _PlaceholderPage(title: 'منشوراتي', subtitle: 'منشوراتك ومراجعتها'),
    _PlaceholderPage(title: 'حسابي', subtitle: 'ملفك الشخصي وإعداداتك'),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('رُشد'), centerTitle: true),
      body: pages[index],
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (value) => setState(() => index = value),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), label: 'الرئيسية'),
          NavigationDestination(icon: Icon(Icons.play_circle_outline), label: 'مقاطع تعليمية'),
          NavigationDestination(icon: Icon(Icons.article_outlined), label: 'منشوراتي'),
          NavigationDestination(icon: Icon(Icons.person_outline), label: 'حسابي'),
        ],
      ),
    );
  }
}

class _PlaceholderPage extends StatelessWidget {
  final String title;
  final String subtitle;
  const _PlaceholderPage({required this.title, required this.subtitle});

  @override
  Widget build(BuildContext context) => Center(
    child: Card(
      color: const Color(0xFF161B22),
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(title, style: Theme.of(context).textTheme.headlineSmall),
            const SizedBox(height: 8),
            Text(subtitle, style: Theme.of(context).textTheme.bodyMedium),
          ],
        ),
      ),
    ),
  );
}
